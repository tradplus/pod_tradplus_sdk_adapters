#import <TradPlusAds/TradPlusAd.h>
#import "KidozSDK.h"

@interface KidozInterstitialCustomEvent : MSInterstitialCustomEvent

@end
