#define TP_KidozAdapter_Version @"7.6.0"
#define TP_KidozAdapter_PlatformSDK_Version @"8.9.0"

