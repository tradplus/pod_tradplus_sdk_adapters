#define TP_KidozAdapter_Version @"8.1.0"
#define TP_KidozAdapter_PlatformSDK_Version @"8.9.0"

