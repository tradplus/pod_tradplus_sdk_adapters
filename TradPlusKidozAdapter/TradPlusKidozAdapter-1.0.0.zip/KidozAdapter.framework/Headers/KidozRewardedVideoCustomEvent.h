#import <TradPlusAds/TradPlusAd.h>
#import "KidozSDK.h"

@interface KidozRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
