#import "KidozSDK.h"
#import <TradPlusAds/TradPlusAd.h>

@interface KidozBannerCustomEvent : MSBannerCustomEvent

@end
