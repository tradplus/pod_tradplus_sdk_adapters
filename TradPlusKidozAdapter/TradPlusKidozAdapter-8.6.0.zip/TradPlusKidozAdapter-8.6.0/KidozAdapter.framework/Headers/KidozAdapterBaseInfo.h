#define TP_KidozAdapter_Version @"8.6.0"
#define TP_KidozAdapter_PlatformSDK_Version @"8.9.3"

