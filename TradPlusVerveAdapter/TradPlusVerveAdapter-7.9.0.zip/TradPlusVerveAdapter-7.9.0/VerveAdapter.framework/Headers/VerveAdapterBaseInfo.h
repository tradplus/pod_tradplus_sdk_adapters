#define TP_VerveAdapter_Version @"7.9.0"
#define TP_VerveAdapter_PlatformSDK_Version @"2.14.0"

