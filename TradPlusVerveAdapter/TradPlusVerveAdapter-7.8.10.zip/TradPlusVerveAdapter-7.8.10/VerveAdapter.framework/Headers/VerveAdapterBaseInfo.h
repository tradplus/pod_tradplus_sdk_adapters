#define TP_VerveAdapter_Version @"7.8.10"
#define TP_VerveAdapter_PlatformSDK_Version @"2.14.0"

