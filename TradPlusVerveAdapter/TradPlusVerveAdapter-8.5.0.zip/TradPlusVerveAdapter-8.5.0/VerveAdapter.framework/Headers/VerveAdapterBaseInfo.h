#define TP_VerveAdapter_Version @"8.5.0"
#define TP_VerveAdapter_PlatformSDK_Version @"2.16.1"

