
#import <UIKit/UIKit.h>
#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusVerveBannerAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
