#define TP_VerveAdapter_Version @"8.4.0"
#define TP_VerveAdapter_PlatformSDK_Version @"2.15.0"

