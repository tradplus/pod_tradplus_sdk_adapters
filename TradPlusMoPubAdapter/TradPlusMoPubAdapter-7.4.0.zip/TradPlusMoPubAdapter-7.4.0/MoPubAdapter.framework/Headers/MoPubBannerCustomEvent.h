//
//  MoPubBannerCustomEvent.h
//  AdExpress
//
//  Copyright (c) 2016 TradPlusAd. All rights reserved.
//

#import <TradPlusAds/MSHTMLBannerCustomEvent.h>

/**
 * Certified with the MoPub iOS SDK version 4.15.1
 */

@interface MoPubBannerCustomEvent : MSBannerCustomEvent

@end
