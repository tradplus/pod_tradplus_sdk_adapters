#import <TradPlusAds/MSNativeCustomEvent.h>

@interface MoPubNativeCustomEvent : MSNativeCustomEvent

@end
