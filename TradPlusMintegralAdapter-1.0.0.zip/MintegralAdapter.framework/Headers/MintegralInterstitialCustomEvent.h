#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface MintegralInterstitialCustomEvent : MSInterstitialCustomEvent

@end
