#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface MintegralRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
