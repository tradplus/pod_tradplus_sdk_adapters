#import <TradPlusAds/MSBannerCustomEvent.h>


NS_ASSUME_NONNULL_BEGIN

@interface MintegralBannerCustomEvent : MSBannerCustomEvent

@end

NS_ASSUME_NONNULL_END
