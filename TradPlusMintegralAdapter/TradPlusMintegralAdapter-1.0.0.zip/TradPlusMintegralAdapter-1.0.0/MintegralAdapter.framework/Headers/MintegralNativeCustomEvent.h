#import <TradPlusAds/MSNativeCustomEvent.h>

@interface MintegralNativeCustomEvent   : MSNativeCustomEvent

@end
