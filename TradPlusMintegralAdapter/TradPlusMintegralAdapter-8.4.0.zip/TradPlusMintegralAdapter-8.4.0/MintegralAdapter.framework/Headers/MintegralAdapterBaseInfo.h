#define TP_MintegralAdapter_Version @"8.4.0"
#define TP_MintegralAdapter_PlatformSDK_Version @"7.2.4"

