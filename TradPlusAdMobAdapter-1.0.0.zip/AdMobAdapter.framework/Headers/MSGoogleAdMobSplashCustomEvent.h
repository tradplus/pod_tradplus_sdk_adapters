#import <TradPlusAds/MSInterstitialCustomEvent.h>


NS_ASSUME_NONNULL_BEGIN

@interface MSGoogleAdMobSplashCustomEvent : MSInterstitialCustomEvent

@end

NS_ASSUME_NONNULL_END
