//
//  TradPlusAdMobSplashAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/9/13.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusAdMobSplashAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
