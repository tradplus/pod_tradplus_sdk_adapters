#define TP_MaioAdapter_Version @"8.6.0"
#define TP_MaioAdapter_PlatformSDK_Version @"1.6.3"

