#define TP_MaioAdapter_Version @"8.2.0"
#define TP_MaioAdapter_PlatformSDK_Version @"1.6.2"

