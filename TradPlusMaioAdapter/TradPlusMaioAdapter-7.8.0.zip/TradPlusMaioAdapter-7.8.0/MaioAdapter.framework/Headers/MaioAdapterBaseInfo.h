#define TP_MaioAdapter_Version @"7.8.0"
#define TP_MaioAdapter_PlatformSDK_Version @"1.6.2"

