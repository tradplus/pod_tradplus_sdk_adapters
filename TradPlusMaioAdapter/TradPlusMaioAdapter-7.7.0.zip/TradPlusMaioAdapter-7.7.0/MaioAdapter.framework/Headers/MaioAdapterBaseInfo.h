#define TP_MaioAdapter_Version @"7.7.0"
#define TP_MaioAdapter_PlatformSDK_Version @"1.6.1"

