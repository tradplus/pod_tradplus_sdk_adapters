#import <TradPlusAds/TradPlusAd.h>

@interface MaioRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
