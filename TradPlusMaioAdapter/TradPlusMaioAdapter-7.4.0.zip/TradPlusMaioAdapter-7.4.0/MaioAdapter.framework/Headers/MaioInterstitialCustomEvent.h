#import <TradPlusAds/TradPlusAd.h>

@interface MaioInterstitialCustomEvent : MSInterstitialCustomEvent

@end
