#define TP_SmaatoAdapter_Version @"7.8.10"
#define TP_SmaatoAdapter_PlatformSDK_Version @"21.7.6"

