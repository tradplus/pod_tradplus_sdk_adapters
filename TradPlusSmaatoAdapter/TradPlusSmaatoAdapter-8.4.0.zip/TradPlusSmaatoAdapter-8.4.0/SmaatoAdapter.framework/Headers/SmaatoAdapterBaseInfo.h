#define TP_SmaatoAdapter_Version @"8.4.0"
#define TP_SmaatoAdapter_PlatformSDK_Version @"21.7.8"

