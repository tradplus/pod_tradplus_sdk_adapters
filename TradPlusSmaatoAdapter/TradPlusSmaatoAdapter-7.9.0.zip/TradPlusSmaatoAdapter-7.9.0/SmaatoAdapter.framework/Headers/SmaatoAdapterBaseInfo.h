#define TP_SmaatoAdapter_Version @"7.9.0"
#define TP_SmaatoAdapter_PlatformSDK_Version @"21.7.6"

