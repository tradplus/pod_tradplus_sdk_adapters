#import <TradPlusAds/MSBannerCustomEvent.h>

@interface SmaatoBannerCustomEvent : MSBannerCustomEvent
@end
