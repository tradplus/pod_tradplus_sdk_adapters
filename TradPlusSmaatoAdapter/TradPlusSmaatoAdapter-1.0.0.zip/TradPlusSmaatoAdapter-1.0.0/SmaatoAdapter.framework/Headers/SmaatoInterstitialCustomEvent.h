#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface SmaatoInterstitialCustomEvent : MSInterstitialCustomEvent
@end
