#define TP_BaiduAdapter_Version @"8.4.0"
#define TP_BaiduAdapter_PlatformSDK_Version @"4.901"

