#define TP_BaiduAdapter_Version @"7.8.10"
#define TP_BaiduAdapter_PlatformSDK_Version @"4.881"

