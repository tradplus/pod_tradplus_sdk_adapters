#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusBaiduRewardedAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
