#define TP_BaiduAdapter_Version @"7.9.0"
#define TP_BaiduAdapter_PlatformSDK_Version @"4.881"

