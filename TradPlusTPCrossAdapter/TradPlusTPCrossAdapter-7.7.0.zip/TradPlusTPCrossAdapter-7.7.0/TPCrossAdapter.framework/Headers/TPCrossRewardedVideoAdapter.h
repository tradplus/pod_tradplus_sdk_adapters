#import <TradPlusAds/TradPlusBaseAdapter.h>

@interface TPCrossRewardedVideoAdapter : TradPlusBaseAdapter

@end
