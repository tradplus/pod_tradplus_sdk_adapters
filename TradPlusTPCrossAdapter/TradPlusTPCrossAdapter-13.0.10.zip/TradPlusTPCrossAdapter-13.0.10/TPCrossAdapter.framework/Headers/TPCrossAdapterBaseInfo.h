#define TP_TPCrossAdapter_Version @"13.0.10"
#define TP_TPCrossAdapter_PlatformSDK_Version @"1.0.1"

