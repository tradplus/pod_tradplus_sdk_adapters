#import <TradPlusAds/TradPlusBaseAdapter.h>

@interface TPCrossInterstitialAdapter : TradPlusBaseAdapter

@end
