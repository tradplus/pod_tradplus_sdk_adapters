#import "TPFullscreenAdAdapter.h"
#import "TPFullscreenAdViewControllerDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface TPFullscreenAdAdapter (Splash) 

- (void)loadSplashAd;

@end

NS_ASSUME_NONNULL_END
