#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface TPCrossRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
