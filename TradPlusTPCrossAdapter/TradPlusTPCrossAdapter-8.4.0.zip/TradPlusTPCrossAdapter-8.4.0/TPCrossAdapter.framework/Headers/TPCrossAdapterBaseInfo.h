#define TP_TPCrossAdapter_Version @"8.4.0"
#define TP_TPCrossAdapter_PlatformSDK_Version @"1.0.0"

