#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface TPCrossInterstitialCustomEvent : MSInterstitialCustomEvent

@end
