#define TP_TPCrossAdapter_Version @"7.8.0"
#define TP_TPCrossAdapter_PlatformSDK_Version @"1.0.0"

