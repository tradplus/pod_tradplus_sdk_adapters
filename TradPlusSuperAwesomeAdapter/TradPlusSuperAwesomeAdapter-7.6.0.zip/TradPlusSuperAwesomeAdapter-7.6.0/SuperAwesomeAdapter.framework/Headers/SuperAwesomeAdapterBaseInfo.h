#define TP_SuperAwesomeAdapter_Version @"7.6.0"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.1.3"

