#define TP_SuperAwesomeAdapter_Version @"8.3.20"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.3.10"

