#define TP_SuperAwesomeAdapter_Version @"7.5.0"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.1.4"

