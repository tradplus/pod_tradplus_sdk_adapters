#define TP_SuperAwesomeAdapter_Version @"8.1.0"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.3.8"

