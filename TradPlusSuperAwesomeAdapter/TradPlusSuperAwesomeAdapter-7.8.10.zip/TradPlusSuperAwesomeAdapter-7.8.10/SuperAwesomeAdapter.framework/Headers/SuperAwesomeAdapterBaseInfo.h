#define TP_SuperAwesomeAdapter_Version @"7.8.10"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.3.8"

