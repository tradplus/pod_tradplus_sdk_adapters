#define TP_SuperAwesomeAdapter_Version @"8.5.0"
#define TP_SuperAwesomeAdapter_PlatformSDK_Version @"8.4.1"

