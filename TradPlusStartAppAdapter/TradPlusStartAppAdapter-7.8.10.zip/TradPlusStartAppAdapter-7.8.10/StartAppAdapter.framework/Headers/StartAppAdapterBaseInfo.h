#define TP_StartAppAdapter_Version @"7.8.10"
#define TP_StartAppAdapter_PlatformSDK_Version @"4.7.1"

