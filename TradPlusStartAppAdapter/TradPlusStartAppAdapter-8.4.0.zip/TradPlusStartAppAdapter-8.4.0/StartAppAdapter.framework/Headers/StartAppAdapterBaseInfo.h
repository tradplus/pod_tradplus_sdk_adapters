#define TP_StartAppAdapter_Version @"8.4.0"
#define TP_StartAppAdapter_PlatformSDK_Version @"4.7.3"

