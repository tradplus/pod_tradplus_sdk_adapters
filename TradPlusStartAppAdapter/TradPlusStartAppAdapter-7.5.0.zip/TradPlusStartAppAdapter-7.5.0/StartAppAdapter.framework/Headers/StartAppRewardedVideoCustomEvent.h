//
//  StartAppRewardedVideoCustomEvent.h
//
//  Copyright © 2017 MeetSocial. All rights reserved.
//

#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface StartAppRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
