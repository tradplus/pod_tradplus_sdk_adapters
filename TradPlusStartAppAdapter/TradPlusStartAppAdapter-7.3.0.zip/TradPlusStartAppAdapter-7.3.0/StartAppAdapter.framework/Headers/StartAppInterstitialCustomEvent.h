//
//  StartAppInterstitialCustomEvent.h
//
//  Copyright (c) 2016 MeetSocial. All rights reserved.
//

#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface StartAppInterstitialCustomEvent : MSInterstitialCustomEvent

@end
