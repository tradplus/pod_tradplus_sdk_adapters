//
//  TPADXVoiceButton.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/10/19.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TPADXVoiceButton : UIButton

//yes = 静音
@property (nonatomic,assign) BOOL isMute;
@end

NS_ASSUME_NONNULL_END
