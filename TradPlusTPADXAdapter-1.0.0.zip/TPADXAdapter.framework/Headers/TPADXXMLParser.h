

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TPADXXMLParser : NSObject


- (NSDictionary * _Nullable)dictionaryWithData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
