#if __has_include(<TradPlusAd/TradPlusAd.h>)
    #import <TradPlusAd/TradPlusAd.h>
#else
    #import <TradPlusAds/MSBannerCustomEvent.h>
#endif

@interface MyTargetBannerCustomEvent : MSBannerCustomEvent

@end
