#define TP_IronSourceAdapter_Version @"7.7.0"
#define TP_IronSourceAdapter_PlatformSDK_Version @"7.2.2.0"

