#define TP_IronSourceAdapter_Version @"8.0.0"
#define TP_IronSourceAdapter_PlatformSDK_Version @"7.2.3.1"

