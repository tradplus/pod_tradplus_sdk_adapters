#define TP_IronSourceAdapter_Version @"7.8.10"
#define TP_IronSourceAdapter_PlatformSDK_Version @"7.2.3.1"

