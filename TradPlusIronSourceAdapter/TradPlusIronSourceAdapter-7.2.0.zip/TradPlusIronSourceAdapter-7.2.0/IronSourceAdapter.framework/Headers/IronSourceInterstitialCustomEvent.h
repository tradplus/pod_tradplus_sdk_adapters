//
//  IronSourceInterstitialCustomEvent.h
//

#import <TradPlusAds/MSInterstitialCustomEvent.h>

#import <IronSource/IronSource.h>
#import "IronSourceInterstitialDelegate.h"
#import "IronSourceManager.h"
#import "IronSourceUtils.h"

@interface IronSourceInterstitialCustomEvent : MSInterstitialCustomEvent


@end
