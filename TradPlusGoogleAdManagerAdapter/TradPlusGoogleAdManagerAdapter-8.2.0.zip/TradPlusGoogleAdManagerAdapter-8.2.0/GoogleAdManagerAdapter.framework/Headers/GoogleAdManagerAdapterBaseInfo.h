#define TP_GoogleAdManagerAdapter_Version @"8.2.0"
#define TP_GoogleAdManagerAdapter_PlatformSDK_Version @"9.9.0"

