#define TP_GoogleAdManagerAdapter_Version @"8.4.0"
#define TP_GoogleAdManagerAdapter_PlatformSDK_Version @"9.11.0"

