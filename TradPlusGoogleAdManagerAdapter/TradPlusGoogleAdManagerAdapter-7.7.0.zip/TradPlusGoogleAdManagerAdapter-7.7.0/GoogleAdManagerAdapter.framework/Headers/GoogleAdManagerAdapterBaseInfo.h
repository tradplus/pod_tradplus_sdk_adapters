#define TP_GoogleAdManagerAdapter_Version @"7.7.0"
#define TP_GoogleAdManagerAdapter_PlatformSDK_Version @"9.5.0"

