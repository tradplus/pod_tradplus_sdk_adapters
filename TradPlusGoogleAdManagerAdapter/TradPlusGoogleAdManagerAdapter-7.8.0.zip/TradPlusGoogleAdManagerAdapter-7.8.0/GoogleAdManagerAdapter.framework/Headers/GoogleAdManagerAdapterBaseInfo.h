#define TP_GoogleAdManagerAdapter_Version @"7.8.0"
#define TP_GoogleAdManagerAdapter_PlatformSDK_Version @"9.7.0"

