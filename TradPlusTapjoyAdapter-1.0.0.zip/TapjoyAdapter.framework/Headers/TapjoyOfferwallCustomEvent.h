#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface TapjoyOfferwallCustomEvent : MSRewardedVideoCustomEvent

@end
