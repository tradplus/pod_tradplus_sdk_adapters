//
//  TradPlusPangleBannerAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/8/27.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusPangleBannerAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
