#define TP_PangleAdapter_Version @"7.5.10"
#define TP_PangleAdapter_PlatformSDK_Version @"4.5.0.1"

