#import <TradPlusAds/MSBannerCustomEvent.h>

@interface PangleBannerCustomEvent : MSBannerCustomEvent

@end
