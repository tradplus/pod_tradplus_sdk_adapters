#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface PangleInterstitialCustomEvent : MSInterstitialCustomEvent

@end
