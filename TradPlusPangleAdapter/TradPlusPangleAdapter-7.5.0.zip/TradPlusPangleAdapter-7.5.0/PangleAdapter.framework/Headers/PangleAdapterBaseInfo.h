#define TP_PangleAdapter_Version @"7.5.0"
#define TP_PangleAdapter_PlatformSDK_Version @"4.3.0.5"

