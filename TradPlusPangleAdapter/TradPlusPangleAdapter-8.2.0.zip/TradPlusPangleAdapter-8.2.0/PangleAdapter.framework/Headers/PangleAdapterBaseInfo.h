#define TP_PangleAdapter_Version @"8.2.0"
#define TP_PangleAdapter_PlatformSDK_Version @"CSJ-4.7.1.1,Pangle-4.7.0.2"

