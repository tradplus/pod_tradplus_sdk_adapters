#define TP_PangleAdapter_Version @"7.7.0"
#define TP_PangleAdapter_PlatformSDK_Version @"4.4.0.7"

