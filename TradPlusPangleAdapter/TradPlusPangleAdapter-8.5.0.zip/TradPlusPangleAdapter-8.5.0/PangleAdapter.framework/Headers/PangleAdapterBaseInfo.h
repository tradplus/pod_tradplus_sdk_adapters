#define TP_PangleAdapter_Version @"8.5.0"
#define TP_PangleAdapter_PlatformSDK_Version @"CSJ-4.8.1.0,Pangle-4.8.0.6"

