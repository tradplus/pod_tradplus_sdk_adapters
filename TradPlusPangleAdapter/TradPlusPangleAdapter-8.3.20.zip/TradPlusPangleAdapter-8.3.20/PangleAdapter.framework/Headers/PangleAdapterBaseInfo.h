#define TP_PangleAdapter_Version @"8.3.20"
#define TP_PangleAdapter_PlatformSDK_Version @"CSJ-4.8.0.8,Pangle-4.7.0.6"

