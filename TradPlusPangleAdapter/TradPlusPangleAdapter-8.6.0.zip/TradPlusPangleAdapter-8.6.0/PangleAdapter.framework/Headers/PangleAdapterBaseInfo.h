#define TP_PangleAdapter_Version @"8.6.0"
#define TP_PangleAdapter_PlatformSDK_Version @"CSJ-4.9.0.6,Pangle-4.8.0.6"

