#import <TradPlusAds/MSBannerCustomEvent.h>

/**
 * Certified with the Facebook iOS SDK version 4.15.1
 */

@interface FacebookBannerCustomEvent : MSBannerCustomEvent

@end
