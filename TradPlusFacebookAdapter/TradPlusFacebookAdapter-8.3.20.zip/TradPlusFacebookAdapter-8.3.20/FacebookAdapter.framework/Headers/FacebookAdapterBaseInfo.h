#define TP_FacebookAdapter_Version @"8.3.20"
#define TP_FacebookAdapter_PlatformSDK_Version @"6.11.2"

