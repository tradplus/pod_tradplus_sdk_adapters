#define TP_FacebookAdapter_Version @"8.5.0"
#define TP_FacebookAdapter_PlatformSDK_Version @"6.12.0"

