#define TP_FacebookAdapter_Version @"7.6.0"
#define TP_FacebookAdapter_PlatformSDK_Version @"6.11.1"

