#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface FacebookRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
