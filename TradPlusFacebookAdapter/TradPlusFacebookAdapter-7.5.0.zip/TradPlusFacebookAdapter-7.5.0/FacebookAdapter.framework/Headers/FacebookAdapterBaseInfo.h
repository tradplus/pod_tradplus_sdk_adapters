#define TP_FacebookAdapter_Version @"7.5.0"
#define TP_FacebookAdapter_PlatformSDK_Version @"6.10.0"

