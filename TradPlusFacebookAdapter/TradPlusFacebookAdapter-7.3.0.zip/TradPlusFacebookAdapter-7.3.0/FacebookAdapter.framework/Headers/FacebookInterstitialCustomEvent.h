#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface FacebookInterstitialCustomEvent : MSInterstitialCustomEvent

@end
