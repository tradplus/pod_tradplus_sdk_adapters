#define TP_FacebookAdapter_Version @"7.8.10"
#define TP_FacebookAdapter_PlatformSDK_Version @"6.11.1"

