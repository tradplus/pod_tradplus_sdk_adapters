#define TP_MyTargetAdapter_Version @"8.2.0"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.15.2"

