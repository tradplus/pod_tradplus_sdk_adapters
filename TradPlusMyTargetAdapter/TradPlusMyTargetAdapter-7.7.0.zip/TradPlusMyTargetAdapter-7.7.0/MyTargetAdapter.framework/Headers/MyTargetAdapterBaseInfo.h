#define TP_MyTargetAdapter_Version @"7.7.0"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.15.1"

