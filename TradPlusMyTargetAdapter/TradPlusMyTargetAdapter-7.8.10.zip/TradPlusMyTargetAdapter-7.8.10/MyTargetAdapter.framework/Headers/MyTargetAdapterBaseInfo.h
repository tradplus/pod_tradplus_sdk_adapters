#define TP_MyTargetAdapter_Version @"7.8.10"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.15.2"

