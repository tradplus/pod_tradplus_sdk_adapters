//
//  TradPlusMyTargetAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/7/23.
//  Copyright © 2021 ms-mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TradPlusAds/TradPlusAdapterProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusMyTargetAdapter : NSObject<TradPlusAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
