#define TP_MyTargetAdapter_Version @"8.1.0"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.15.2"

