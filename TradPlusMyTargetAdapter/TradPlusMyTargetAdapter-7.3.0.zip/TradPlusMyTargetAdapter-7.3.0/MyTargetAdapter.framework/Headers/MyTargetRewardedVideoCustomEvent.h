#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface MyTargetRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
