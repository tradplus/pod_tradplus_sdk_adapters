#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface MyTargetInterstitialCustomEvent : MSInterstitialCustomEvent

@end
