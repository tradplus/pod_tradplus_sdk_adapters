#define TP_MyTargetAdapter_Version @"7.6.0"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.15.1"

