#define TP_MyTargetAdapter_Version @"8.4.0"
#define TP_MyTargetAdapter_PlatformSDK_Version @"5.16.0"

