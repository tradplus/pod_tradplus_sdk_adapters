#define TP_OguryAdapter_Version @"7.6.0"
#define TP_OguryAdapter_PlatformSDK_Version @"2.5.1"

