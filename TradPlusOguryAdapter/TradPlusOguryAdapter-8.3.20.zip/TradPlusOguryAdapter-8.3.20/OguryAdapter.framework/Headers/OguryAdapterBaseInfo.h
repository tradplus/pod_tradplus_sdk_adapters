#define TP_OguryAdapter_Version @"8.3.20"
#define TP_OguryAdapter_PlatformSDK_Version @"2.1.0"

