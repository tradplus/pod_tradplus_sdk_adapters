#define TP_VungleAdapter_Version @"7.5.0"
#define TP_VungleAdapter_PlatformSDK_Version @"6.10.6"

