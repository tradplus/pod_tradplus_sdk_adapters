#define TP_VungleAdapter_Version @"15.5.0"
#define TP_VungleAdapter_PlatformSDK_Version @"7.7.1"

