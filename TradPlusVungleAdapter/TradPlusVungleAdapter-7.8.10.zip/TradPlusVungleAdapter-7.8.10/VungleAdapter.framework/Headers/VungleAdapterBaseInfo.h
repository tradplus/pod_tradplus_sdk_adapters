#define TP_VungleAdapter_Version @"7.8.10"
#define TP_VungleAdapter_PlatformSDK_Version @"6.11.0"

