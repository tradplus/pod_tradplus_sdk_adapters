//
//  VungleNativeCustomEvent.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/7/1.
//  Copyright © 2021 ms-mac. All rights reserved.
//

#import <TradPlusAds/MSNativeCustomEvent.h>

NS_ASSUME_NONNULL_BEGIN

@interface VungleNativeCustomEvent : MSNativeCustomEvent

@end

NS_ASSUME_NONNULL_END
