#import <TradPlusAds/MSBannerCustomEvent.h>

@interface VungleBannerCustomEvent : MSBannerCustomEvent

@end

