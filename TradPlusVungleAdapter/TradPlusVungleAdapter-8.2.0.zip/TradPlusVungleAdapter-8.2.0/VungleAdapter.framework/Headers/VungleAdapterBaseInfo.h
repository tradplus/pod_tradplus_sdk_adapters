#define TP_VungleAdapter_Version @"8.2.0"
#define TP_VungleAdapter_PlatformSDK_Version @"6.12.0"

