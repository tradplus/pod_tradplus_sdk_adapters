#define TP_GDTMobAdapter_Version @"7.9.0"
#define TP_GDTMobAdapter_PlatformSDK_Version @"4.13.81"

