#import <TradPlusAds/MSBannerCustomEvent.h>

@interface GDTMobBannerCustomEvent : MSBannerCustomEvent

@end
