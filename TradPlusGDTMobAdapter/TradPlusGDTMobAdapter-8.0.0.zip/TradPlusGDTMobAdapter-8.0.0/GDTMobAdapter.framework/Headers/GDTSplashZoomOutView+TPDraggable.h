//
//  GDTSplashZoomOutView+GDTDraggable.h
//  GDTMobApp
//
//  Created by nimomeng on 2020/11/18.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "GDTSplashZoomOutView.h"

NS_ASSUME_NONNULL_BEGIN

@interface GDTSplashZoomOutView (TPDraggable)
- (void)supportDrag;
@end

NS_ASSUME_NONNULL_END
