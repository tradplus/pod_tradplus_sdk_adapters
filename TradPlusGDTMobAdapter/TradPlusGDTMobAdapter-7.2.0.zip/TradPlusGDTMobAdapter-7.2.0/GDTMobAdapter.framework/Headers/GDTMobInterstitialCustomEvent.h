#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface GDTMobInterstitialCustomEvent : MSInterstitialCustomEvent

@end
