#define TP_GDTMobAdapter_Version @"8.3.20"
#define TP_GDTMobAdapter_PlatformSDK_Version @"4.13.90"

