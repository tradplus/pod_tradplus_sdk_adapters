#define TP_FyberAdapter_Version @"7.9.0"
#define TP_FyberAdapter_PlatformSDK_Version @"8.1.5"

