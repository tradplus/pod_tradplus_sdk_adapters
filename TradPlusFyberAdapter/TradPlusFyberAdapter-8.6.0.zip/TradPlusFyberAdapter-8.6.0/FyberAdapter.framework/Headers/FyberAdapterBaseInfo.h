#define TP_FyberAdapter_Version @"8.6.0"
#define TP_FyberAdapter_PlatformSDK_Version @"8.1.7"

