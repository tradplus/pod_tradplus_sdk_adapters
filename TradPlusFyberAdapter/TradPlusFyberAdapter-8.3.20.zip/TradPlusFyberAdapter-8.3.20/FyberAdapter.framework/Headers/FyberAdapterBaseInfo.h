#define TP_FyberAdapter_Version @"8.3.20"
#define TP_FyberAdapter_PlatformSDK_Version @"8.1.6"

