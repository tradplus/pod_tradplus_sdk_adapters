#define TP_YandexAdapter_Version @"8.6.0"
#define TP_YandexAdapter_PlatformSDK_Version @"5.2.1"

