#define TP_YandexAdapter_Version @"7.8.10"
#define TP_YandexAdapter_PlatformSDK_Version @"5.0.2"

