#define TP_YandexAdapter_Version @"7.9.0"
#define TP_YandexAdapter_PlatformSDK_Version @"5.1.0"

