#define TP_YandexAdapter_Version @"8.1.0"
#define TP_YandexAdapter_PlatformSDK_Version @"5.1.0"

