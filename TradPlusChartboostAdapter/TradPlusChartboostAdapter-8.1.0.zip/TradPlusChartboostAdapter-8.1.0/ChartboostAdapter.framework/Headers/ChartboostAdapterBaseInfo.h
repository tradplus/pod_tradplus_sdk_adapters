#define TP_ChartboostAdapter_Version @"8.1.0"
#define TP_ChartboostAdapter_PlatformSDK_Version @"8.5.0.2"

