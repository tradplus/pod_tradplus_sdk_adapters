//
//  TradPlusChartboostRewardedAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/9/7.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusChartboostRewardedAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
