#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface ChartboostRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
