#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface ChartboostInterstitialCustomEvent : MSInterstitialCustomEvent
@end
