#import <TradPlusAds/MSBannerCustomEvent.h>

@interface ChartboostBannerCustomEvent : MSBannerCustomEvent

@end
