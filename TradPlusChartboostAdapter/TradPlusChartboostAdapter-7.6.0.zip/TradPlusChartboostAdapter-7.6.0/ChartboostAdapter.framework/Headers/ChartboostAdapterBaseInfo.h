#define TP_ChartboostAdapter_Version @"7.6.0"
#define TP_ChartboostAdapter_PlatformSDK_Version @"8.5.0.2"

