#define TP_AdMobAdapter_Version @"12.6.10"
#define TP_AdMobAdapter_PlatformSDK_Version @"11.12.0"

