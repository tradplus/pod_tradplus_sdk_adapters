#import <TradPlusAds/MSInterstitialCustomEvent.h>

/*
 * Certified with version 7.1.0 of the Google AdMob Ads SDK.
 */

@interface MSGoogleAdMobInterstitialCustomEvent : MSInterstitialCustomEvent

@end
