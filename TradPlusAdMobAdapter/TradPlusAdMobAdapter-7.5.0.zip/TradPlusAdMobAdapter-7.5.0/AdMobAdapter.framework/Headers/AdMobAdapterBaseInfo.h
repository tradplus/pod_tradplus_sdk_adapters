#define TP_AdMobAdapter_Version @"7.5.0"
#define TP_AdMobAdapter_PlatformSDK_Version @"9.3.0"

