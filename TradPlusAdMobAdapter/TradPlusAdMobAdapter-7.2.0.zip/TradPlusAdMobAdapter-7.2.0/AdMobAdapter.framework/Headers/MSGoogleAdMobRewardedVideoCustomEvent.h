#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface MSGoogleAdMobRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
