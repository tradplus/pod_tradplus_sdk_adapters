#define TP_AdColonyAdapter_Version @"8.1.0"
#define TP_AdColonyAdapter_PlatformSDK_Version @"4.9.0"

