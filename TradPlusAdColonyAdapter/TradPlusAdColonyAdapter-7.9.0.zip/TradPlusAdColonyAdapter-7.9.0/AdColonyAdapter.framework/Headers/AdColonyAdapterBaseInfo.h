#define TP_AdColonyAdapter_Version @"7.9.0"
#define TP_AdColonyAdapter_PlatformSDK_Version @"4.9.0"

