#define TP_AdColonyAdapter_Version @"8.3.20"
#define TP_AdColonyAdapter_PlatformSDK_Version @"4.9.0"

