//
//  AdColonyRewardedVideoCustomEvent.h
//  TradPlusSDK
//
//  Copyright (c) 2016 TradPlus. All rights reserved.
//

#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

/*
 * Please reference the Supported Mediation Partner page at http://bit.ly/2mqsuFH for the
 * latest version and ad format certifications.
 */
@interface AdColonyRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
