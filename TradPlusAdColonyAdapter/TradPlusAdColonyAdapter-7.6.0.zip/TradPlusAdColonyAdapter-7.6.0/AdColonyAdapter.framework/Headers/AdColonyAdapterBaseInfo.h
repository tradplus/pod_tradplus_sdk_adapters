#define TP_AdColonyAdapter_Version @"7.6.0"
#define TP_AdColonyAdapter_PlatformSDK_Version @"4.8.0"

