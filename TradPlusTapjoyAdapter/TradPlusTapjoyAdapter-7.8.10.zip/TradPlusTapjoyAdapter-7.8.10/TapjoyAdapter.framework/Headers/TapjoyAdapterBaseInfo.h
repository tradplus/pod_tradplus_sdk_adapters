#define TP_TapjoyAdapter_Version @"7.8.10"
#define TP_TapjoyAdapter_PlatformSDK_Version @"12.10.0"

