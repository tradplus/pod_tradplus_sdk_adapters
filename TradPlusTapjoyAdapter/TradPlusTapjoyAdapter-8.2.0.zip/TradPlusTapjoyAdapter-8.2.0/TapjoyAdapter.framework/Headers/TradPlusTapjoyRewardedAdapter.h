//
//  TradPlusTapjoyRewardedAdapter.h
//  fluteSDKSample
//
//  Created by xuejun on 2021/9/8.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusTapjoyRewardedAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
