#define TP_TapjoyAdapter_Version @"7.8.0"
#define TP_TapjoyAdapter_PlatformSDK_Version @"12.10.0"

