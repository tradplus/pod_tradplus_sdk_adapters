#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface TapjoyRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
