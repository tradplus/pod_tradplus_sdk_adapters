#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface TapjoyInterstitialCustomEvent : MSInterstitialCustomEvent
@end
