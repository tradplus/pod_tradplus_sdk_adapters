#define TP_TapjoyAdapter_Version @"7.5.0"
#define TP_TapjoyAdapter_PlatformSDK_Version @"12.9.1"

