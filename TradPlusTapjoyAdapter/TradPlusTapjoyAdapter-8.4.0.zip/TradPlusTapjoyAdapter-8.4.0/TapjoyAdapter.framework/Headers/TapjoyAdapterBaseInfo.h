#define TP_TapjoyAdapter_Version @"8.4.0"
#define TP_TapjoyAdapter_PlatformSDK_Version @"12.11.0"

