#define TP_TapjoyAdapter_Version @"8.1.0"
#define TP_TapjoyAdapter_PlatformSDK_Version @"12.10.0"

