#define TP_BigoAdapter_Version @"8.4.0"
#define TP_BigoAdapter_PlatformSDK_Version @"1.8.7"

