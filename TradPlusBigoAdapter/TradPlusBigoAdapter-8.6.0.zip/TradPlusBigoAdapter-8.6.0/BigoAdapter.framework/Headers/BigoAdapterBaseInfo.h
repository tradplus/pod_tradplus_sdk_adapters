#define TP_BigoAdapter_Version @"8.6.0"
#define TP_BigoAdapter_PlatformSDK_Version @"1.9.1"

