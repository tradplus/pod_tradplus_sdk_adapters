#define TP_BigoAdapter_Version @"8.5.0"
#define TP_BigoAdapter_PlatformSDK_Version @"1.8.7"

