#define TP_KlevinAdapter_Version @"8.6.0"
#define TP_KlevinAdapter_PlatformSDK_Version @"2.11.0.215"

