//
//  TradPlusKlevinNativeAdapter.h
//  fluteSDKSample
//
//  Created by hy on 2021/10/25.
//  Copyright © 2021 TradPlus. All rights reserved.
//

#import <TradPlusAds/TradPlusBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusKlevinNativeAdapter : TradPlusBaseAdapter

@end

NS_ASSUME_NONNULL_END
