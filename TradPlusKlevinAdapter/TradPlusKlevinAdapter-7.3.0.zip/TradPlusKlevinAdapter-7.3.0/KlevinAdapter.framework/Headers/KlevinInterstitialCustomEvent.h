#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface KlevinInterstitialCustomEvent : MSInterstitialCustomEvent

@end
