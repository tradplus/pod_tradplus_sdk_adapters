#define TP_KlevinAdapter_Version @"7.6.0"
#define TP_KlevinAdapter_PlatformSDK_Version @"2.8.0.237"

