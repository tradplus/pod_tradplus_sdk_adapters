#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface KlevinRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
