#define TP_KlevinAdapter_Version @"7.8.10"
#define TP_KlevinAdapter_PlatformSDK_Version @"2.9.0.216"

