#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface SmaatoRewardedVideoCustomEvent : MSRewardedVideoCustomEvent
@end
