#import <TradPlusAds/MSInterstitialCustomEvent.h>


NS_ASSUME_NONNULL_BEGIN

@interface PangleSplashCustomEvent : MSInterstitialCustomEvent

@end

NS_ASSUME_NONNULL_END
