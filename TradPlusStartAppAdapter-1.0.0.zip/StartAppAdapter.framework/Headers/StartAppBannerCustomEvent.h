//
//  StartAppBannerCustomEvent.h
//
//  Copyright (c) 2016 MeetSocial. All rights reserved.
//

#import <TradPlusAds/MSBannerCustomEvent.h>


@interface StartAppBannerCustomEvent : MSBannerCustomEvent

@end
