#import <TradPlusAds/MSHTMLBannerCustomEvent.h>

@interface AppLovinBannerCustomEvent : MSBannerCustomEvent

@end
