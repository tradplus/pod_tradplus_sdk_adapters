#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

// PLEASE NOTE: We have renamed this class from "AppLovinRewardedCustomEvent" to "AppLovinRewardedVideoCustomEvent", you can use either classname in your TradPlus account.
@interface AppLovinRewardedVideoCustomEvent : MSRewardedVideoCustomEvent
@end

// AppLovinRewardedCustomEvent is deprecated but kept here for backwards-compatibility purposes.
@interface AppLovinRewardedCustomEvent : AppLovinRewardedVideoCustomEvent
@end
