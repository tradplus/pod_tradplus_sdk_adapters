#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface AppLovinInterstitialCustomEvent : MSInterstitialCustomEvent

@end
