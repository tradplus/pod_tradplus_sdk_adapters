#define TP_AppLovinAdapter_Version @"8.3.20"
#define TP_AppLovinAdapter_PlatformSDK_Version @"11.5.0"

