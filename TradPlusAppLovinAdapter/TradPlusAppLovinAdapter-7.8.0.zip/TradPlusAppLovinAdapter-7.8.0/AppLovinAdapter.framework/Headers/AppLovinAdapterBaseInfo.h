#define TP_AppLovinAdapter_Version @"7.8.0"
#define TP_AppLovinAdapter_PlatformSDK_Version @"11.4.3"

