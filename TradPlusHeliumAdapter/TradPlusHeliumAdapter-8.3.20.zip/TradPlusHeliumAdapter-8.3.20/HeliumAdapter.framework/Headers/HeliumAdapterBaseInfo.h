#define TP_HeliumAdapter_Version @"8.3.20"
#define TP_HeliumAdapter_PlatformSDK_Version @"3.0.0"

