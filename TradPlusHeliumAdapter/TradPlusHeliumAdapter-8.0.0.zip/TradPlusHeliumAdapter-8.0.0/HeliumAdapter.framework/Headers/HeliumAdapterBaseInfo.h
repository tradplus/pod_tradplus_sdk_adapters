#define TP_HeliumAdapter_Version @"8.0.0"
#define TP_HeliumAdapter_PlatformSDK_Version @"2.11.0"

