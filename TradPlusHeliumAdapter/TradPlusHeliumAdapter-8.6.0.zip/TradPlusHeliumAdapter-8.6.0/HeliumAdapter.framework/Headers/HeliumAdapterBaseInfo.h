#define TP_HeliumAdapter_Version @"8.6.0"
#define TP_HeliumAdapter_PlatformSDK_Version @"3.2.0"

