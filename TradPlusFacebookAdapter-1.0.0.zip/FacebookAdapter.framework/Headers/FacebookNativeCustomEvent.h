#import <TradPlusAds/MSNativeCustomEvent.h>

@interface FacebookNativeCustomEvent : MSNativeCustomEvent

@end
