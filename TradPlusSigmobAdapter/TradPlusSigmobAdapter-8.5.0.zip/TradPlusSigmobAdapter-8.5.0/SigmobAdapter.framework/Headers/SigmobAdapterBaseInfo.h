#define TP_SigmobAdapter_Version @"8.5.0"
#define TP_SigmobAdapter_PlatformSDK_Version @"4.6.1"

