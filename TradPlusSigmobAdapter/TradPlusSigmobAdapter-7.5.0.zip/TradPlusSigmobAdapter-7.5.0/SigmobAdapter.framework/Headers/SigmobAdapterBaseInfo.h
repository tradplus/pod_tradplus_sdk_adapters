#define TP_SigmobAdapter_Version @"7.5.0"
#define TP_SigmobAdapter_PlatformSDK_Version @"3.5.4"

