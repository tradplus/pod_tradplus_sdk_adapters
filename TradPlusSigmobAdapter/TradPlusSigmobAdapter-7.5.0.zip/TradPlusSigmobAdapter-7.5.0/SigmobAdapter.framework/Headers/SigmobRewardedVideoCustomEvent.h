//
//  SigmobRewardedVideoCustomEvent.h
//
//  Copyright © 2017 TradPlusAd. All rights reserved.
//

#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface SigmobRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
