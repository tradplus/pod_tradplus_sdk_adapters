#define TP_SigmobAdapter_Version @"8.4.0"
#define TP_SigmobAdapter_PlatformSDK_Version @"4.5.0"

