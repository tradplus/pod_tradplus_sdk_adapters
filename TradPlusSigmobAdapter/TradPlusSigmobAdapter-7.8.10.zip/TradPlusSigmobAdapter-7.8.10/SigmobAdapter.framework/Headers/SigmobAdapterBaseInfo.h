#define TP_SigmobAdapter_Version @"7.8.10"
#define TP_SigmobAdapter_PlatformSDK_Version @"4.1.1"

