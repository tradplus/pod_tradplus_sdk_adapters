#define TP_SigmobAdapter_Version @"8.0.0"
#define TP_SigmobAdapter_PlatformSDK_Version @"4.2.1"

