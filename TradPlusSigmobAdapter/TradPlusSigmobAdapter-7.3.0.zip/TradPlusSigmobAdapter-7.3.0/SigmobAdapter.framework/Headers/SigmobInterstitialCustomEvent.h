//
//  SigmobInterstitialCustomEvent.h
//
//  Copyright © 2017 TradPlusAd. All rights reserved.
//

#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface SigmobInterstitialCustomEvent : MSInterstitialCustomEvent

@end
