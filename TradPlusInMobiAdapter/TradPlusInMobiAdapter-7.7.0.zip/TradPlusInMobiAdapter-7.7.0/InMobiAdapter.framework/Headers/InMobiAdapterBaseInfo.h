#define TP_InMobiAdapter_Version @"7.7.0"
#define TP_InMobiAdapter_PlatformSDK_Version @"10.0.7"

