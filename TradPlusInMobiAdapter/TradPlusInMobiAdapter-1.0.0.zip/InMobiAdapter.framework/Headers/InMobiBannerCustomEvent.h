#import <TradPlusAds/MSBannerCustomEvent.h>


@interface InMobiBannerCustomEvent : MSBannerCustomEvent

@end
