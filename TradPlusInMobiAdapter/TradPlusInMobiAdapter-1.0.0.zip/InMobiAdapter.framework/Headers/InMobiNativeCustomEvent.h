#import <TradPlusAds/MSNativeCustomEvent.h>

@interface InMobiNativeCustomEvent : MSNativeCustomEvent

@end
