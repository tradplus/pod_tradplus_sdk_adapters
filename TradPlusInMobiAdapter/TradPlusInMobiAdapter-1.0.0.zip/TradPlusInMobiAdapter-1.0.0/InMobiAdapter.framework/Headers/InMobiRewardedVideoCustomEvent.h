#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface InMobiRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
