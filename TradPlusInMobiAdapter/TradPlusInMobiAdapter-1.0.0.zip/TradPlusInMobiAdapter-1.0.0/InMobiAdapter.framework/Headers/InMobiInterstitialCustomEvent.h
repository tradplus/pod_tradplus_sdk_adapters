#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface InMobiInterstitialCustomEvent : MSInterstitialCustomEvent

@end
