#define TP_InMobiAdapter_Version @"8.6.0"
#define TP_InMobiAdapter_PlatformSDK_Version @"10.1.1"

