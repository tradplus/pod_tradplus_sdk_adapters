#define TP_UnityAdapter_Version @"7.9.0"
#define TP_UnityAdapter_PlatformSDK_Version @"4.2.1"

