#import <UnityAds/UADSBannerViewDelegate.h>

#import <TradPlusAds/TradPlusAd.h>

@interface UnityAdsBannerCustomEvent : MSBannerCustomEvent<UADSBannerViewDelegate>

@end
