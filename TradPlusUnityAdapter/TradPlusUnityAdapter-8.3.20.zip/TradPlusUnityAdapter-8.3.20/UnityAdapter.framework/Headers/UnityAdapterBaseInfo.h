#define TP_UnityAdapter_Version @"8.3.20"
#define TP_UnityAdapter_PlatformSDK_Version @"4.4.0"

