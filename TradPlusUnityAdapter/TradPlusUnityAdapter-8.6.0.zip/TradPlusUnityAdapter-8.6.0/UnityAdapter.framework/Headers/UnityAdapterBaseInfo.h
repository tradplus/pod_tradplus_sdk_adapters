#define TP_UnityAdapter_Version @"8.6.0"
#define TP_UnityAdapter_PlatformSDK_Version @"4.4.1"

