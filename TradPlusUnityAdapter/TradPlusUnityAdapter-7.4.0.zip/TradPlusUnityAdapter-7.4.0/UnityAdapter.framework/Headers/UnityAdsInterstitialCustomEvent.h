#import <TradPlusAds/TradPlusAd.h>

@interface UnityAdsInterstitialCustomEvent : MSInterstitialCustomEvent

@end
