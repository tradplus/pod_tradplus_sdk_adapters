#import <TradPlusAds/TradPlusAd.h>

@interface UnityAdsRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
