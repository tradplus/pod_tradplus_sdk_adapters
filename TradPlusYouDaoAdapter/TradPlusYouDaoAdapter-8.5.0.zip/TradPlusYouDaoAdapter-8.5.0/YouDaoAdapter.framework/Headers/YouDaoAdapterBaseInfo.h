#define TP_YouDaoAdapter_Version @"8.5.0"
#define TP_YouDaoAdapter_PlatformSDK_Version @"2.16.14"

