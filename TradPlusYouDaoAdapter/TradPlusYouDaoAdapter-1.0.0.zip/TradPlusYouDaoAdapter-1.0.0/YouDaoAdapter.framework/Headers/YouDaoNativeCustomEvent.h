#import <TradPlusAds/MSNativeCustomEvent.h>

@interface YouDaoNativeCustomEvent : MSNativeCustomEvent

@end
