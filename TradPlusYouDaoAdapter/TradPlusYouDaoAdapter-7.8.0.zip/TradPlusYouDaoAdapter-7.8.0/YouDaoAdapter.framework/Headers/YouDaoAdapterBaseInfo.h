#define TP_YouDaoAdapter_Version @"7.8.0"
#define TP_YouDaoAdapter_PlatformSDK_Version @"2.16.12"

