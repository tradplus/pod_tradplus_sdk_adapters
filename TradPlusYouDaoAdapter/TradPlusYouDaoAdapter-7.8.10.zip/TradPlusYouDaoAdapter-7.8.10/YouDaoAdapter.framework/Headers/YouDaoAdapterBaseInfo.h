#define TP_YouDaoAdapter_Version @"7.8.10"
#define TP_YouDaoAdapter_PlatformSDK_Version @"2.16.12"

