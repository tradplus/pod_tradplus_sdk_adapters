#define TP_YouDaoAdapter_Version @"8.3.20"
#define TP_YouDaoAdapter_PlatformSDK_Version @"2.16.14"

