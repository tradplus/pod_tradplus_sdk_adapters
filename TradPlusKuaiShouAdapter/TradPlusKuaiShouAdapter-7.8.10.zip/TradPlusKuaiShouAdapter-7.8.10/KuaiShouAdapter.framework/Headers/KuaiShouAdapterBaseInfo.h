#define TP_KuaiShouAdapter_Version @"7.8.10"
#define TP_KuaiShouAdapter_PlatformSDK_Version @"3.3.26"

