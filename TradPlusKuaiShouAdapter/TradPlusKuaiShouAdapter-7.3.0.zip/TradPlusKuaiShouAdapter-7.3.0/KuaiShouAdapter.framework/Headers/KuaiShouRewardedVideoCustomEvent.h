#import <TradPlusAds/MSRewardedVideoCustomEvent.h>

@interface KuaiShouRewardedVideoCustomEvent : MSRewardedVideoCustomEvent

@end
