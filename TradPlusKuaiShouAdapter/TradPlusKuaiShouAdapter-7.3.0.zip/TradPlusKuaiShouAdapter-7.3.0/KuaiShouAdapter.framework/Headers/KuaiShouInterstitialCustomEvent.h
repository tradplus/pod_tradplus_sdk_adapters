#import <TradPlusAds/MSInterstitialCustomEvent.h>

@interface KuaiShouInterstitialCustomEvent : MSInterstitialCustomEvent

@end
