#import <Foundation/Foundation.h>
#import <TradPlusAds/TradPlusAdapterProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TradPlusKuaiShouAdapter : NSObject<TradPlusAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
