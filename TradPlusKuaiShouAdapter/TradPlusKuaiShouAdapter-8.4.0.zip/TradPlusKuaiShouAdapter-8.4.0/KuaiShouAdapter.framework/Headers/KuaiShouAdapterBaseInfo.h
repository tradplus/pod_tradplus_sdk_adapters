#define TP_KuaiShouAdapter_Version @"8.4.0"
#define TP_KuaiShouAdapter_PlatformSDK_Version @"3.3.32"

